# Strategic-handoff supporting logs — 2026-04-29

Zip contents accompanying `TIER-EVAL-STRATEGIC-HANDOFF-20260429.md`.

## run-traces/
The 11 failed-tail run-id directories from the tier-64 production sweep (the
W4 Pass 1 dataset I classified). Each contains:
  - `iterations.jsonl`        — per-iteration tool-call telemetry
  - `bridge.iterations.jsonl` — bridge-side timing/token telemetry
  - `run_summary.json`        — per-run aggregates
  - `assertion_result.json`   — verify-script outcome
  - `sessions/<…>/`           — claw session JSONL with model outputs

## sweep-state/
  - `iter-distribution-runs.csv`                — current run table (post loop-2; restore)
  - `iter-distribution-runs.pre-pilot-20260429.csv` — frozen production-sweep snapshot
  - `_sweep-manifest.json` / `_sweep-manifest.pre-pilot-20260429.json` — sweep provenance
  - `_pilot-manifest.json` / `_pilot.log`        — loop-2 pilot artifacts
  - `_sweep.log`                                  — production-sweep execution log

## pass1-tooling/
  - `summarize-trace.py` — compact-iter-by-iter summarizer used to read the 11 failed traces
  - `all-traces.txt`     — output for all 11, in the order classified in the report

## prior-classifications/
W4 Pass 1 + Pass 2 stratified classification CSVs from the prior n=20 sweep
(frozen 2026-04-28; reference data for the κ baseline cited in the audit).

## companion-docs/
Markdown docs the strategic handoff references inline:
  - `TIER-EVAL-SUITE-AUDIT.md`             — original audit (commit d34a59b)
  - `TIER-EVAL-PILOT-LOOPS-FINDING-20260429.md` — escalation note from loops 1+2
  - `W4-TAXONOMY.md`                       — frozen failure-mode taxonomy (Class E now deprecated)
  - `W4-TAXONOMY-PRODUCTIVE.md`            — productive-iteration taxonomy
  - `W2-W3-RESULTS-20260428.md`            — prior n=20 distribution results
