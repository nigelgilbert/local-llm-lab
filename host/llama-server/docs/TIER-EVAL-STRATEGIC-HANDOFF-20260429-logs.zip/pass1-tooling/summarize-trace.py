#!/usr/bin/env python3
"""Summarize a claw run trace into a compact, reviewable form for W4 Pass 1.

Reads iterations.jsonl + assertion_result.json + run_summary.json from a run-id
directory and emits a single block per iteration:

  iter N  tool=NAMES  changed=bool  error=class:signature(60c)

Plus a header with run-level metadata and a footer with the assertion outcome.
"""
import json
import sys
from pathlib import Path
from collections import Counter


def summarize(run_dir: Path) -> str:
    iters = run_dir / "iterations.jsonl"
    summary_p = run_dir / "run_summary.json"
    assertion_p = run_dir / "assertion_result.json"

    summary = json.loads(summary_p.read_text()) if summary_p.exists() else {}
    assertion = json.loads(assertion_p.read_text()) if assertion_p.exists() else {}

    out = []
    out.append(f"=== {run_dir.name} ({summary.get('test_id','?')}/{summary.get('sampler_id','?')}) ===")
    out.append(f"iter_count={summary.get('iter_count')} terminal={summary.get('terminal_status')} exit={summary.get('exit_code')} "
               f"wall={summary.get('total_wallclock_ms') or summary.get('wallclock_ms')}ms passed={assertion.get('passed')}")
    if assertion.get("post_stderr_tail"):
        tail = assertion["post_stderr_tail"][:300].replace("\n", " | ")
        out.append(f"post_stderr_tail: {tail}")
    out.append("")

    if not iters.exists():
        out.append("(no iterations.jsonl)")
        return "\n".join(out)

    sigs = Counter()
    tool_names_total = Counter()
    workspace_change_count = 0
    error_iters = []

    for line in iters.read_text().splitlines():
        if not line.strip():
            continue
        rec = json.loads(line)
        iter_n = rec.get("iter")
        tools = rec.get("tool_calls") or []
        names = [t.get("name") for t in tools]
        for n in names:
            tool_names_total[n] += 1
        changed = any(t.get("workspace_changed") for t in tools)
        if changed:
            workspace_change_count += 1
        errors = [t for t in tools if t.get("result_is_error")]
        err_sigs = [t.get("result_error_signature") for t in errors if t.get("result_error_signature")]
        for sig in err_sigs:
            sigs[sig[:80]] += 1
        if errors:
            error_iters.append(iter_n)
        # Compact one-line iter view
        tool_str = ",".join(names) if names else "(none)"
        ch_str = "*" if changed else " "
        err_str = ""
        if errors:
            sig0 = err_sigs[0][:60] if err_sigs else (errors[0].get("result_error_class") or "err")
            err_str = f"  err:{sig0}"
        repeated = []
        for t in tools:
            if t.get("result_changed_vs_previous_same_call") is False:
                repeated.append(t.get("name"))
        rep_str = f"  rep:{','.join(repeated)}" if repeated else ""
        out.append(f"iter {iter_n:>3} {ch_str} {tool_str:<60}{err_str}{rep_str}")

    out.append("")
    out.append(f"workspace_changed_iters={workspace_change_count}  error_iters={len(error_iters)}")
    out.append(f"tool_call_totals: {dict(tool_names_total.most_common())}")
    if sigs:
        out.append("error_signatures (top):")
        for sig, n in sigs.most_common(5):
            out.append(f"  ({n}x) {sig}")
    return "\n".join(out)


if __name__ == "__main__":
    for arg in sys.argv[1:]:
        print(summarize(Path(arg)))
        print()
